<?php
/**
 * 
 */
class Loco_error_LocaleException extends Loco_error_Exception {
    
}
