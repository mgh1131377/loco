<h2>
    Installed languages
</h2>
<p>
    This screen lists all the languages that are installed in your WordPress.
    For a language to show up here, you must have the WordPress core translation files installed.
</p>
<p>
    Clicking a language takes you to its translation management screen.
</p>